package com.example.dublinparkswebapp.council;

public class CouncilNotFoundException extends Throwable {
    public CouncilNotFoundException(String message) {
        super(message);
    }
}
